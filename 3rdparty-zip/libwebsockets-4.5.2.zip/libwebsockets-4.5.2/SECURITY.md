# Security Policy

If you become aware of an issue with lws that has a security dimension for users, please contact andy@warmcat.com by direct email.

## Procedure for announcing vulnerability fixes
The problem and fixed versions will be announced by a note added to the main README.md.
