See [Wizard](https://mongoose.ws/wizard/#/output?board=xmc7200&ide=GCC+make&rtos=baremetal&file=README.md)
