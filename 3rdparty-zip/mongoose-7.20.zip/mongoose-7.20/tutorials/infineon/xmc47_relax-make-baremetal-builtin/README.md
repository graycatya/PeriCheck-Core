See [Wizard](https://mongoose.ws/wizard/#/output?board=xmc4700&ide=GCC+make&rtos=baremetal&file=README.md)
