#pragma once

#define MG_ARCH MG_ARCH_ESP32
