See detailed tutorial at https://mongoose.ws/tutorials/mqtt/mqtt-server/
