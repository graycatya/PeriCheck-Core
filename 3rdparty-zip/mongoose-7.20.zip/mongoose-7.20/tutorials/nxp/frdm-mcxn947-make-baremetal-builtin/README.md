See [Wizard](https://mongoose.ws/wizard/#/output?board=mcxn947&ide=GCC+make&rtos=baremetal&file=README.md)
