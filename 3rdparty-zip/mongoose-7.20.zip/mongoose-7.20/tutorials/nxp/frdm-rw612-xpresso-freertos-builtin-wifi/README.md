This example assumes your FRDM-RW612 board already has the Wi-Fi submodule firmware already burned to flash. This seems to be the case for new boards.

In case this is not so, please follow indications in NXP's "frdmrw612_wifi_webconfig" example, components/conn_fwloader/readme.txt

