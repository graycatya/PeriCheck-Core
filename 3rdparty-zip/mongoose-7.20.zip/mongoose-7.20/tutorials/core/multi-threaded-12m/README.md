See detailed tutorial at https://mongoose.ws/tutorials/core/multi-threaded/
