See detailed tutorial at https://mongoose.ws/tutorials/http/http-server/
