#define MG_ARCH MG_ARCH_ESP32

#define MG_ENABLE_PACKED_FS 1
#define MG_TLS MG_TLS_NONE	// change to 'MG_TLS_MBED' to enable TLS
#define MG_OTA MG_OTA_CUSTOM
