#pragma once

#include "Arduino.h"

#define MG_ARCH MG_ARCH_ESP32
